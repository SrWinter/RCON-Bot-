import bot

bot.run()
