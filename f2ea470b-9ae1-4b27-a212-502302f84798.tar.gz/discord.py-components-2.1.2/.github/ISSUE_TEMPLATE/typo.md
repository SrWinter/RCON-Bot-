---
name: Report a Typo
about: Is there a typo?
title: "[Typo] "
labels: typo
---

## Typo type
- [ ] Document
- [ ] Markdown files or Templates

## Typo
> Where is the typo? (line, file github URL) (Multiple possible)
